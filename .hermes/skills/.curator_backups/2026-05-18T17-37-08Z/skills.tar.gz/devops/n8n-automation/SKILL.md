---
name: n8n-automation
description: Manage, troubleshoot, and extend n8n workflow automations. Covers MCP integration, direct database access, common node patterns (dedupe, scoring, summarization), and persistence strategies. Provides templates and scripts for reliable workflow construction.
version: 1.0.0
author: Hermes Agent (session-augmented)
license: MIT
category: devops
tags: [n8n, workflow, automation, MCP, integration, deduplication, troubleshooting]
---

# n8n Automation

This skill gives everything needed to work with n8n workflow automation from Hermes: building, patching, testing, and fixing workflows, including MCP access, database edits, and resilient node patterns.

## When to Use

- Build or modify an n8n workflow
- Debug an execution that stops at a particular node
- Integrate n8n with Hermes (bi-directional triggers, news briefings, alerts)
- Implement deduplication, scoring, summarization, or file output patterns
- Troubleshoot permissions, SSRF, container mounts, or API connectivity

## Prerequisites

- A running n8n instance (Docker or native)
- An API token or JWT with workflow edit rights (Personal API key)
- Optional: MCP server configured for direct access

## Setup

1. **Verify n8n health**  
   ```bash
   curl -sS http://localhost:5678/api/v1/healthz
   ```
   Should return `{"status":"OK"}`. If not, check container logs (`docker logs n8n`).

2. **Obtain an API key** from n8n UI: Settings → API → Create new key. Copy the JWT.

3. **Configure Hermes**  
   - For MCP: ensure `N8N_API_URL` and `N8N_API_KEY` are set in the MCP server config.
   - For direct DB edits: the n8n SQLite database is usually at `~/.n8n/database.sqlite` (or in your mounted volume). Hermes must have read/write access.

4. **Disable strict SSRF if needed** (see Troubleshooting). You can set `N8N_MCP_STRICT_MODE=false` in the n8n container environment for MCP tool access.

## Core Patterns

### Deduplication Node (Function)

Use the following robust pattern inside a Function node to deduplicate items across runs. It stores state via `$getWorkflowStaticData` (with fallback) and also supports content hashing:

```javascript
// references/dedupe-node-pattern.js
const store = (typeof $getWorkflowStaticData === 'function')
  ? $getWorkflowStaticData('global')
  : (typeof getWorkflowStaticData === 'function' ? getWorkflowStaticData('global') : {});
store.urls = store.urls || {};
store.titles = store.titles || {};
store.hashes = store.hashes || {};
const sevenDays = 7 * 24 * 60 * 60 * 1000;
const now = new Date().toISOString();
const newItems = [];

function isOlderThan7Days(ts) {
  if (!ts) return false;
  try { return (Date.now() - new Date(ts).getTime()) > sevenDays; } catch (e) { return true; }
}
function safeString(val) {
  if (val == null) return '';
  return String(val);
}
if (!Array.isArray(items)) {
  console.error('Dedupe: expected items array, got:', items);
  return items || [];
}
for (const item of items) {
  try {
    const data = item.json || {};
    const title = safeString(data.title);
    const url = safeString(data.url || data.link);
    if (!url && !title) continue;
    const normTitle = title.toLowerCase().replace(/[^a-z0-9\\s]/g, '').trim();
    if (!normTitle && !url) continue;

    if (url && store.urls[url] && !isOlderThan7Days(store.urls[url])) {
      item.duplicate = true; item.duplicate_reason = 'url'; continue;
    }
    if (normTitle && store.titles[normTitle] && !isOlderThan7Days(store.titles[normTitle])) {
      item.duplicate = true; item.duplicate_reason = 'title'; continue;
    }

    const content = safeString(data.raw_content || data.content || data.description || '');
    let hash = '';
    if (content.length > 0) {
      try {
        const crypto = require('crypto');
        hash = crypto.createHash('sha1').update(content.substring(0, 500)).digest('hex');
        if (store.hashes[hash] && !isOlderThan7Days(store.hashes[hash])) {
          item.duplicate = true; item.duplicate_reason = 'content'; continue;
        }
      } catch (e) { hash = ''; }
    }

    newItems.push(item);
    if (url) store.urls[url] = now;
    if (normTitle) store.titles[normTitle] = now;
    if (hash) store.hashes[hash] = now;
  } catch (err) {
    console.error('Dedupe item error:', err.message);
    newItems.push(item); // keep item on error
  }
}
function prune(obj) {
  for (const key in obj) {
    if (isOlderThan7Days(obj[key])) delete obj[key];
  }
}
prune(store.urls);
prune(store.titles);
prune(store.hashes);
console.log(`Dedupe: processed ${items.length} items, kept ${newItems.length}, store sizes: urls=${Object.keys(store.urls).length}, titles=${Object.keys(store.titles).length}, hashes=${Object.keys(store.hashes).length}`);
return newItems;
```

**Why this works**
- Works with both `$getWorkflowStaticData` and `getWorkflowStaticData` depending on n8n version.
- Survives restarts; data persists in n8n’s internal store.
- Prunes old entries (>7 days) to keep store small.
- Logs summary counts for debugging.

### File Output Pattern

When you need to write a Markdown briefing to disk, use the `Read/Write File` node. Ensure the path is inside `/files/` and the directory exists on the host. Example:
```
/files/briefings/{{$now.format('YYYY-MM-DD_HH')}}.md
```
The container must have the mount: `-v /host/path/automation_outputs:/files`.

### Summarization with Local LLM

Use a Function node to call `OLLAMA_BASE_URL` (or another provider). See `linear` and `docker-management` skills for similar patterns.

### MCP Access

If MCP tools are blocked by SSRF, you can either:
- Disable strict mode in the n8n container: `-e N8N_MCP_STRICT_MODE=false`
- Or, when using direct curl, rely on the JWT token in the `Authorization: Bearer <token>` header.

## Troubleshooting

### SSRF Protection Blocks Localhost

**Symptom**: MCP tools error with “SSRF protection: Localhost access is blocked in strict mode”.

**Fix**:
- Restart n8n with env var `N8N_MCP_STRICT_MODE=false`.
- Or, configure MCP server to use `host.docker.internal` if Docker on Linux adds that host.
- Example Docker run:
  ```bash
  docker run -d --name n8n -p 5678:5678 \
    -e N8N_MCP_STRICT_MODE=false \
    -v /home/openclaw/openclaw-command-center/automation_outputs:/files \
    n8nio/n8n:2.18.5
  ```

### Deduplicate Node Throws `$getWorkflowStaticData is not defined`

**Cause**: The Function node expects `$getWorkflowStaticData` but the variable name differs by n8n version.

**Fix**: Use the compatibility pattern shown above (check both `$` and non `$` variants).

### Missing `/files` Directory or Permission Denied

**Fix**:
```bash
mkdir -p /home/openclaw/openclaw-command-center/automation_outputs/{briefings,logs}
chmod -R 777 /home/openclaw/openclaw-command-center/automation_outputs  # temporary for testing
```
Also verify the container mount is present: `docker inspect n8n | grep -A 2 Mounts`.

### Workflow Not Appearing After Container Restart

n8n stores workflows in its internal database. If you manually edited the SQLite file, ensure correct ownership (`node:node` UID/GID). You can also import via UI: Workflows → Import → JSON.

### Execution Stops at a Node with No Output

Check that the node actually returns an array of items. In Function nodes, ensure you end with `return newItems;`. Log intermediate values using `console.log` and view execution logs in the UI.

## Reference Files

- `references/dedupe-node-pattern.js` – robust deduplication code to paste into any Function node.
- `references/disable-ssrf-strict-mode.md` – steps to turn off strict SSRF protection.
- `references/n8n-health-check.sh` – quick connectivity probe.

## Templates

- `templates/workflow-skeleton.json` – minimal workflow JSON structure with common nodes (trigger, action, output).

## Scripts

- `scripts/verify-n8n-connection.sh` – prints `OK` if n8n health endpoint responds.

---

*This skill is living. When you discover a new workflow pattern or a tricky fix, add it here.*