---
name: operational-audit
description: Conduct systematic operational reviews of Hermes and associated infrastructure over a specified time period
version: 0.1.0
author: Jason (via Hermes)
category: devops
tags:
  - review
  - health-check
  - audit
  - reporting
---

## Overview

This skill guides the assistant in performing a comprehensive operational review, also known as a health check or audit, covering a defined time window (typically 72 hours). It produces a structured report with sections: Executive Summary, Completed Work, Partially Completed, Requested But Not Completed, Blockers, Needs from User, Next Steps, Recommendations, Recurring Patterns, Priority Ranking, and Final Checklist.

## Trigger

User asks for an operational review, system health check, project status update, or similar request that requires analyzing past activity, logs, and state over a time period.

## Process

1. **Define Scope** – Clarify time range (default 72 hours), systems to include (Hermes, n8n, Bot_Exchange, etc.), and any specific focus areas.
2. **Data Collection** – Use appropriate tools:
   - `session_search` with appropriate queries to retrieve relevant conversations.
   - `terminal` to run status commands (`hermes gateway status`, `docker ps`, `df -h`, `pgrep -f ...`).
   - `read_file` to inspect logs (`~/.hermes/logs/gateway.log`), config files, task queues (`Bot_Exchange/queue/*`), and workspace notes.
   - Avoid large one‑off dumps; read only necessary files and filter to relevant time slices.
3. **Categorize Findings** – Populate the report structure:
   - Completed Work: tasks with clear evidence of completion.
   - Partially Completed Work: started but not finished; note remaining steps and blockers.
   - Requested But Not Completed: tasks asked for but never acted on.
   - Blockers: current impediments, who/what is blocking, and what is needed to unblock.
   - Recommendations: concrete, actionable improvements with implementation steps.
   - Recurring Patterns: note repeated issues (ownership gaps, missing inputs, tool failures, etc.).
4. **Prioritization** – Rank next actions by urgency, impact, and dependency risk.
5. **Output** – Assemble the report in the requested format, using clear tables and bullet points. If the report becomes too long (>4000 words or >10 sections), consider splitting into multiple messages or provide an executive summary with an offer to send full details.

## Pitfalls

- **Stdout Limit**: Using `execute_code` to print entire large files (e.g., logs, JSON dumps) can exceed the 50KB stdout limit and truncate results. Instead, read files with `read_file` and extract only needed snippets; or in scripts, accumulate data without printing it all, and print a concise summary.
- **Message Length Limit**: The overall response may be truncated if it exceeds ~10,000 characters. If the draft report is huge, break it into parts: send the Executive Summary and then follow with sections on separate turns, or compress by removing redundant details while preserving the table structure.
- **Gateway Polling Conflicts**: Repeated warnings like “Telegram polling conflict (1/3)” indicate multiple gateway instances or token reuse. Ensure only one gateway process is managed by systemd (`systemctl --user status hermes-gateway`). Kill any stray processes and rely on systemd exclusively. If conflicts persist, check for other bots using the same token.
- **Port Conflicts**: When starting a service (e.g., dashboard), check if the port is already in use (`ss -tulpn | grep :PORT`). If an old instance is running, kill it before starting a new one, or configure a different port.
- **Empty Directories**: If a required directory (e.g., `agency-agents`) is empty because the source was missing, define a fallback source (e.g., `~/.hermes/skills/`) and populate it to avoid broken automation.
- **Incomplete Follow‑Through**: Investigations often gather data (curl outputs, file lists) but analysis stops before conclusions and fixes. After data collection, immediately synthesize findings and propose concrete actions.

## Templates

The standard operational review template is available in this skill. See `templates/report_template.md` for a ready‑to‑use skeleton that matches the required output sections.

## Scripts

- `scripts/gather_common_status.sh` – Collects basic system status (gateway, disk, processes) in a concise format suitable for inclusion in reports.

## Reference

Key insights from this session’s audit:
- Dashboard already running on port 8787 from `/media/sf_ClawdbotShared/Brain/command_center_panel/app.py` (PID 39326) needed to be killed before starting the workspace copy.
- `agency-agents` populated by copying from `/home/openclaw/openclaw-command-center/agency-agents/` (785 files).
- Operation_Instructions.md integration into Hermes config via `system_prompt` was chosen and implemented.
- Bot_Exchange queue worker skill (`bot-exchange-queue-worker`) was created to formalize the pattern.
- Newsletter automation status diagnosed: n8n workflow identified; if inactive, it should be activated; `librarian_worker.py` should be running as a background process.
- Gateway polling conflicts persisted but were not critical; check for duplicate processes and ensure systemd‑only management.
- MCP n8n SSRF protection blocks localhost; using curl workaround is acceptable but better to allow localhost in `mcp_servers.n8n.allowed_hosts`.

## Revision History

- v0.1.0 (2026‑05‑12) – Initial creation based on 72‑hour review of Hermes command‑center rebuild.