---
name: system-health-audit
description: Systematic health check of Hermes/OpenClaw infrastructure services. Verifies n8n, Brain API, Docker containers, key processes, and provides status reporting with recovery guidance.
trigger:
  - "make sure all systems are up"
  - "check system status"
  - "are all services running"
  - "system health"
  - "service status"
category: devops
---

### Steps

1. **Check n8n**:  
   `curl -s -o /dev/null -w "%{http_code}" http://localhost:5678` → expect `200`.  
   Or load `n8n-automation` skill for deeper checks.

2. **Check Hermes gateway process**:  
   `ps aux | grep -E "hermes.*gateway" | grep -v grep` → should show a running Python process.

3. **Check Brain API**:  
   `curl -s http://192.168.56.1:8090/health` → expected JSON (see `references/brain_api_setup.md`).  
   - If unreachable, try fallback IPs: `192.168.1.151`, `100.67.101.95`.  
   - **Important**: The Brain API runs on the Windows host, not on the Ubuntu VM. The VM only consumes it over HTTP.

4. **Check Docker containers**:  
   `docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}"` → ensure expected containers (e.g., `n8n`) are up.

5. **Check other known services**:  
   - **Brain Command Center Panel**: `curl -s http://127.0.0.1:8787` (serves a UI).  
   - **Enki Browser**: `curl -s http://127.0.0.1:4318` (Node.js API; may return 404 on `/` – that’s normal).  
   - Any additional services documented in your environment.

6. **Compile status report**:  
   Assemble a table with Service, Expected Endpoint, Status, and Notes.

7. **Recovery recommendations** (if issues found):  
   - **Brain API down**: SSH into Windows host (`user Jason`, key `~/.ssh/enkii_windows_ed25519`) and run:  
     ```powershell
     cd R:\codex\brain-stack
     docker compose up -d
     ```  
     Ensure Windows Firewall permits inbound TCP 8090 on the host‑only network.  
   - **Missing SSH key**: generate with `ssh-keygen -t ed25519 -f ~/.ssh/enkii_windows_ed25519 -N ""` and install the public key on Windows (see `references/ssh_key_setup.md`).  
   - Other services: consult the corresponding skill (e.g., `n8n-automation`, `debugging-hermes-tui-commands`).

### Pitfalls

- **Brain API location**: It is *not* the Python `command_center_panel` app. That is a separate UI. The real API lives on the Windows host.
- **VirtualBox IP**: The default `192.168.56.1` is the host‑only adapter; it may change if network configuration changed. Use fallback IPs if needed.
- **SSH key**: The private key `enkii_windows_ed25519` must exist on the VM and the public key must be in `C:\Users\Jason\.ssh\authorized_keys` on Windows. Verify with `scripts/test_vm_to_windows_ssh.sh`.
- **Enki Browser**: Returns 404 on `/`; that’s expected. Its API endpoints are under `/api/` or similar; no dedicated health check.
- **command_center_panel**: This is a Flask UI, not the Brain ingestion API. Do not confuse.

### References
- `references/brain_api_setup.md` – Brain API endpoints, health check, expected response, and ingest interface.
- `references/ssh_key_setup.md` – SSH configuration for VM→Windows access and key management.
- `references/known_services.md` – Summary of services and their typical ports/processes in this environment.
